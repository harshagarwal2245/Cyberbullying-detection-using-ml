"""
to get function identified by pytest always write function name starting with 
test example test_env
function should always contain assert function if assert is true test is passed
"""

def test_generic():
    a=2
    b=2
    assert a == b